package com.google.jpa.learningjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
